

public class Album {
    public static final String DEFAULT_TITLE = "Renaissance";
    public static final String DEFAULT_PERFORMER = "Beyonce";
    public static final int DEFAULT_NUM_SONGS = 10;
    public static final String DEFAULT_GENRE = "easy listening";

    private String title;
    private String performer;
    private String genre;
    private int numSongs;
    
    public Album() {
        this(DEFAULT_TITLE, DEFAULT_PERFORMER, DEFAULT_GENRE, DEFAULT_NUM_SONGS);
    }

    public Album(String title, String performer, String genre, int numSongs) {
        this.title = title;
        this.performer = performer;
        setGenre(genre);
        setNumSongs(numSongs);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPerformer() {
        return performer;
    }

    public void setPerformer(String performer) {
        this.performer = performer;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        String[] validGenres = {"hip-hop", "easy listening", "orchestral", "your parents", "theatre"};
        boolean isValid = false;

        for (String validGenre : validGenres) {
            if (genre.equals(validGenre)) {
                isValid = true;
                break;
            }
        }

        if (isValid) {
            this.genre = genre;
        } else {
            this.genre = DEFAULT_GENRE;
        }
    }

    public int getNumSongs() {
        return numSongs;
    }

    public void setNumSongs(int numSongs) {
        if (numSongs < 10) {
            this.numSongs = DEFAULT_NUM_SONGS;
        } else {
            this.numSongs = numSongs;
        }
    }

    public boolean isLong() {
        return numSongs > 50;
    }

    @Override
    public String toString() {
        return "Album: " + title + ", Performer: " + performer + ", Genre: " + genre + ", Number of Songs: " + numSongs;
    }
}
