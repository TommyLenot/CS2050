import java.util.Scanner;

public class Program1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        for (int i = 1; i <= 3; i++) {
            System.out.println("Enter details for Album " + i + ":");

            System.out.print("Enter title: ");
            String title = scanner.nextLine();

            System.out.print("Enter performer: ");
            String performer = scanner.nextLine();

            System.out.print("Enter genre: ");
            String genre = scanner.nextLine();

            System.out.print("Enter number of songs: ");
            int numSongs = scanner.nextInt();
            scanner.nextLine();

            Album album = new Album(title, performer, genre, numSongs);

            System.out.println("\nDetails of Album " + i + ":");
            System.out.println(album.toString());
            System.out.println("Is the album long? " + album.isLong());
            System.out.println();
        }

        scanner.close();
    }
}

